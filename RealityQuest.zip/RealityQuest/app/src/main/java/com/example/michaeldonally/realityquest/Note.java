package com.example.michaeldonally.realityquest;

/**
 * Created by Michael Donally on 10/27/2016.
 * This is a helper class to help us organize chunks of strings that occur freuently in our code
 */

public class Note {
    String title;
    String text;

    public Note(String t, String b) {
        this.title = t;
        this.text = b;
    }

    public void setTitle(String newT) {
        this.title = newT;
    }

    public void setText(String newText) {
        this.text = newText;
    }

    public String getTitle() {
        return this.title;
    }

    public String getText() {
        return this.text;
    }


}
