package com.example.michaeldonally.realityquest;

/**
 * Created by Michael Donally on 10/25/2016.
 */

public class User {

    String name;
    int level;//Be it player level or dungeon creator level, this may be implemented later
    Coor myCoordinates;

    public Coor getCoor() {
        //This function will updates the Coor object myCoordinates using the google maps api
        //Updates it t devices current coordinates
        return null;
    }

    public User() {


    }

    public void setLevel(int l) {level = l;};
    public void setName(String n) {
        name = n;
    }
}
