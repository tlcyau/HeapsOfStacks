package com.example.michaeldonally.realityquest;

/**
 * Created by Michael Donally on 10/27/2016.
 */

public class Map {
    //Since every subsequent marker knows its next marker, the map only needs to know the first to set players on the right direction
    Marker firstMarker;
    String title;
    int rating;
    User user;
    int plays;

    //We will have a full map view not showing your location and one that is just you to the next marker
    boolean viewType;

    public void displayMap() {
        //Displays the current map (set or markers) scaled to fit together like a map
        //Idk how we're gonna do this yet
        //Displays diferently based on map type
    }

    public void updateMap() {
        //Will update based on user cordinates
    }

    public void setMarker(Marker m){
        this.firstMarker = m;
    }

    public void setTitle(String t) {
        this.title = t;
    }


}